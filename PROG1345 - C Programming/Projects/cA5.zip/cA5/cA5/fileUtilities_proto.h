int getSmallFileLength ( char* fqpn );
int readBinaryFileToBuffer (unsigned char* buffer, char* fqpn, int fileSize);
int writeBufferToFile (char* buffer, char* fqpn);